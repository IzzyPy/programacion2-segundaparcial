Proyecto Android completo (nivel proyecto académico) con:
- Captura de 3 fotos con cámara y envío multipart a webhook.site
- Selección múltiple de archivos, compresión ZIP y envío multipart
- Room para logs (LogApp) y WorkManager para sincronización
- Nota: WorkManager PeriodicWorkRequest mínimo 15 minutos por restricción de Android
